from distutils.core import setup
from setuptools import find_packages
import glob

package_data = ['nn/NNFiles/*'] 
scripts = glob.glob('bin/*')               

setup(
  name = 'ADTLibrary',
  packages=find_packages(exclude=[]), # this must be the same as the name above
  version = '0.3',
  description = 'A random test lib',
  author = 'Carl Southall',
  author_email = 'c-southall@live.co.uk',
  license='BID',
  url = 'https://github.com/CarlSouthall/ADTLibrary', # use the URL to the github repo
  download_url = 'https://github.com/CarlSouthall/ADTLibrary', # I'll explain this in a second
  keywords = ['testing', 'logging', 'example'], # arbitrary keywords
  classifiers = ['Programming Language :: Python :: 2',
    'Programming Language :: Python :: 2.6',
    'Programming Language :: Python :: 2.7',
    'Programming Language :: Python :: 3',
    'Programming Language :: Python :: 3.2',
    'Programming Language :: Python :: 3.3',
    'Programming Language :: Python :: 3.4',],
    scripts=scripts,
   
    install_requires=['numpy','scipy','cython','madmom','tensorflow'],
    package_data={'AutoDrum': package_data}, 
)
